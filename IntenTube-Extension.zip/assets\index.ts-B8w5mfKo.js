import{n as e}from"./analytics-CVWa1MRi.js";var t=[`jee`,`physics`,`chemistry`,`mathematics`,`calculus`,`organic chemistry`,`iit`,`neet`,`programming`];async function n(){return new Promise(n=>{chrome.storage.sync.get({keywords:t,focusModeDisabledUntil:0,videosBlocked:0,focusStreak:0,lastActiveDate:``,focusGoal:``,studyGoal:null,rating:0,featureRequest:``,pollVote:``},t=>{t.studyGoal!==null&&t.studyGoal!==void 0&&(t.focusGoal||=t.studyGoal,chrome.storage.sync.set({focusGoal:t.focusGoal}),chrome.storage.sync.remove(`studyGoal`),delete t.studyGoal);let r=t,i=new Date().toISOString().split(`T`)[0];if(r.lastActiveDate!==i){if(e(`Daily Active User`,{date:i}),r.lastActiveDate){let e=new Date(r.lastActiveDate),t=new Date(i),n=Math.floor((t.getTime()-e.getTime())/(1e3*60*60*24));n===1?r.focusStreak+=1:n>1&&(r.focusStreak=1)}else r.focusStreak=1;r.lastActiveDate=i,chrome.storage.sync.set({focusStreak:r.focusStreak,lastActiveDate:i})}n(r)})})}async function r(e){return new Promise(t=>{chrome.storage.sync.set(e,()=>{t()})})}async function i(t=1){await r({videosBlocked:(await n()).videosBlocked+t}),e(`Video Blocked`,{count:t})}async function a(){let e=await n();return Date.now()>e.focusModeDisabledUntil}async function o(t){await r({focusModeDisabledUntil:Date.now()+t*60*1e3}),e(`Focus Mode Disabled`,{durationMinutes:t})}var s=null,c=!1,l=null,u=[`Focus is a matter of deciding what things you're not going to do. - John Carmack`,`The successful warrior is the average man, with laser-like focus. - Bruce Lee`,`Concentrate all your thoughts upon the work at hand. The sun's rays do not burn until brought to a focus. - Alexander Graham Bell`,`Lack of direction, not lack of time, is the problem. We all have twenty-four hour days. - Zig Ziglar`,`Starve your distractions, feed your focus. - Unknown`];async function d(){if(window.location.pathname!==`/`){m();return}if(!await a()){m();return}c||=(i(10),!0);let e=document.querySelector(`ytd-browse[page-subtype="home"] #primary`);e&&e.style.setProperty(`display`,`none`,`important`);let t=await n();f(),p(t)}function f(){if(document.getElementById(`intentube-dashboard-styles`))return;let e=document.createElement(`style`);e.id=`intentube-dashboard-styles`,e.textContent=`
    .intentube-dashboard {
      width: 100%;
      min-height: 85vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      background: transparent;
      font-family: 'Inter', -apple-system, sans-serif;
      color: #F8FAFC;
      padding: 40px;
      box-sizing: border-box;
    }
    
    .st-header {
      display: flex;
      justify-content: space-between;
      width: 100%;
      max-width: 800px;
      margin-bottom: 40px;
      align-items: center;
    }
    
    .st-logo {
      font-size: 24px;
      font-weight: 700;
      letter-spacing: -0.5px;
    }
    
    .st-clock {
      font-size: 16px;
      color: #94A3B8;
      font-weight: 500;
    }
    
    .st-glass-card {
      background: rgba(17, 24, 39, 0.6);
      backdrop-filter: blur(12px);
      -webkit-backdrop-filter: blur(12px);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 16px;
      padding: 24px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    }
    
    .st-hero {
      width: 100%;
      max-width: 800px;
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
      margin-bottom: 32px;
    }
    
    .st-goal-title {
      font-size: 14px;
      color: #3B82F6;
      text-transform: uppercase;
      font-weight: 600;
      letter-spacing: 1px;
      margin-bottom: 8px;
    }
    
    .st-goal-text {
      font-size: 32px;
      font-weight: 700;
      margin: 0 0 16px 0;
      color: #FFFFFF;
    }
    
    .st-quote {
      font-size: 16px;
      color: #94A3B8;
      font-style: italic;
      max-width: 600px;
      line-height: 1.5;
    }
    
    .st-stats-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 20px;
      width: 100%;
      max-width: 800px;
      margin-bottom: 40px;
    }
    
    .st-stat-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 24px;
      transition: transform 0.2s ease, background 0.2s ease;
    }
    
    .st-stat-card:hover {
      transform: translateY(-4px);
      background: rgba(17, 24, 39, 0.8);
    }
    
    .st-stat-value {
      font-size: 32px;
      font-weight: 700;
      color: #F8FAFC;
      margin-bottom: 8px;
    }
    
    .st-stat-value.score {
      color: #22C55E;
    }
    
    .st-stat-label {
      font-size: 13px;
      color: #64748B;
      text-transform: uppercase;
      font-weight: 600;
      letter-spacing: 0.5px;
    }
    
    .st-quick-search {
      width: 100%;
      max-width: 800px;
      margin-bottom: 40px;
    }
    
    .st-quick-search-title {
      font-size: 14px;
      color: #94A3B8;
      text-transform: uppercase;
      font-weight: 600;
      letter-spacing: 0.5px;
      margin-bottom: 16px;
    }
    
    .st-chips-container {
      display: flex;
      flex-wrap: wrap;
      gap: 12px;
    }
    
    .st-chip {
      background: rgba(59, 130, 246, 0.1);
      border: 1px solid rgba(59, 130, 246, 0.3);
      color: #3B82F6;
      padding: 10px 20px;
      border-radius: 20px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      text-decoration: none;
      transition: all 0.2s ease;
    }
    
    .st-chip:hover {
      background: rgba(59, 130, 246, 0.2);
      transform: translateY(-2px);
    }
    
    .st-controls {
      display: flex;
      gap: 16px;
    }
    
    .st-btn-primary {
      background: white;
      color: black;
      border: none;
      padding: 14px 28px;
      border-radius: 28px;
      font-size: 16px;
      font-weight: 700;
      cursor: pointer;
      transition: transform 0.2s ease, opacity 0.2s ease;
    }
    
    .st-btn-primary:hover {
      transform: scale(1.05);
      opacity: 0.9;
    }
    
    .st-btn-secondary {
      background: #1E293B;
      color: white;
      border: 1px solid #334155;
      padding: 14px 28px;
      border-radius: 28px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
    }
    
    .st-btn-secondary:hover {
      background: #334155;
    }
  `,document.head.appendChild(e)}function p(e){if(document.getElementById(`intentube-homepage-overlay`))return;let t=document.querySelector(`ytd-browse[page-subtype="home"]`)||document.body;s=document.createElement(`div`),s.id=`intentube-homepage-overlay`,s.className=`intentube-dashboard`;let n=e.videosBlocked*5,r=Math.floor(n/60),i=n%60,a=r>0?`${r}h ${i}m`:`${i}m`,c=Math.min(100,Math.max(0,30+e.focusStreak*5+Math.min(50,e.videosBlocked*.5))),d=u[Math.floor(Math.random()*u.length)],f=document.createElement(`div`);f.className=`st-header`;let p=document.createElement(`div`);p.className=`st-logo`,p.style.display=`flex`,p.style.alignItems=`center`,p.style.gap=`10px`;let m=document.createElement(`img`);m.src=chrome.runtime.getURL(`icon.png`),m.style.width=`32px`,m.style.height=`32px`,m.style.objectFit=`contain`;let h=document.createTextNode(`IntenTube`);p.appendChild(m),p.appendChild(h);let g=document.createElement(`div`);g.className=`st-clock`;let _=()=>{let e=new Date;g.textContent=e.toLocaleDateString(void 0,{weekday:`long`,month:`short`,day:`numeric`})+` • `+e.toLocaleTimeString([],{hour:`2-digit`,minute:`2-digit`})};_(),l=window.setInterval(_,1e3),f.appendChild(p),f.appendChild(g);let v=document.createElement(`div`);v.className=`st-glass-card st-hero`;let y=document.createElement(`div`);y.className=`st-goal-title`,y.textContent=`🎯 Current Goal`;let b=document.createElement(`div`);b.className=`st-goal-text`,b.textContent=e.focusGoal||`No goal set. Open extension to set one.`;let x=document.createElement(`div`);x.className=`st-quote`,x.textContent=`"${d}"`,v.appendChild(y),v.appendChild(b),v.appendChild(x);let S=document.createElement(`div`);S.className=`st-stats-grid`;let C=(e,t,n=!1)=>{let r=document.createElement(`div`);r.className=`st-glass-card st-stat-card`;let i=document.createElement(`div`);i.className=`st-stat-value ${n?`score`:``}`,i.textContent=e;let a=document.createElement(`div`);return a.className=`st-stat-label`,a.textContent=t,r.appendChild(i),r.appendChild(a),r};S.appendChild(C(Math.round(c).toString(),`Focus Score`,!0)),S.appendChild(C(e.videosBlocked.toString(),`Blocked`)),S.appendChild(C(a,`Time Saved`)),S.appendChild(C(`${e.focusStreak} 🔥`,`Streak`));let w=document.createElement(`div`);w.className=`st-quick-search`;let T=document.createElement(`div`);T.className=`st-quick-search-title`,T.textContent=`Quick Start`;let E=document.createElement(`div`);E.className=`st-chips-container`,(e.keywords.length>0?e.keywords.slice(0,5):[`Physics`,`Chemistry`,`Mathematics`,`Programming`]).forEach(e=>{let t=document.createElement(`a`);t.className=`st-chip`,t.textContent=e.charAt(0).toUpperCase()+e.slice(1),t.href=`/results?search_query=${encodeURIComponent(e)}`,E.appendChild(t)}),w.appendChild(T),w.appendChild(E);let D=document.createElement(`div`);D.className=`st-controls`;let O=document.createElement(`button`);O.className=`st-btn-primary`,O.textContent=`Go to Search`,O.onclick=()=>{window.scrollTo({top:0,behavior:`smooth`});let e=document.querySelector(`input#search, ytd-searchbox input`);e&&e.focus()};let k=document.createElement(`button`);k.className=`st-btn-secondary`,k.textContent=`Disable Focus Mode (5m)`,k.onclick=async()=>{await o(5),window.location.reload()},D.appendChild(O),D.appendChild(k),s.appendChild(f),s.appendChild(v),s.appendChild(S),s.appendChild(w),s.appendChild(D),t.appendChild(s)}function m(){l&&=(clearInterval(l),null),s&&=(s.remove(),null);let e=document.querySelector(`ytd-browse[page-subtype="home"] #primary`);e&&e.style.removeProperty(`display`)}var h=!1;async function g(){if(await a()){if(window.location.pathname.startsWith(`/shorts/`)){console.log(`Shorts blocked`),window.location.replace(`/`),h||=(i(1),!0);return}document.querySelectorAll([`ytd-reel-shelf-renderer`,`ytd-reel-video-renderer`,`ytd-rich-shelf-renderer[is-shorts]`].join(`, `)).forEach(e=>{e.style.setProperty(`display`,`none`,`important`)}),document.querySelectorAll(`a[href*="/shorts/"]`).forEach(e=>{let t=e.closest(`ytd-rich-item-renderer, ytd-video-renderer, ytd-compact-video-renderer, ytd-grid-video-renderer`);t?t.style.setProperty(`display`,`none`,`important`):e.style.setProperty(`display`,`none`,`important`)})}}function _(e,t,n){let r=`${e} ${t}`.toLowerCase();return n.some(e=>r.includes(e.toLowerCase()))}async function v(){if(window.location.pathname!==`/watch`||!await a())return;let e=(await n()).keywords;document.querySelectorAll(`ytd-compact-video-renderer`).forEach(t=>{if(t.hasAttribute(`data-intentube-processed`))return;let n=Array.from(t.querySelectorAll(`.badge-shape-label, .ytd-badge-supported-renderer`)).some(e=>e.textContent?.trim()===`Sponsored`||e.textContent?.trim()===`Ad`),r=``,a=``;if(n||t.tagName.toLowerCase()===`ytd-ad-slot-renderer`)r=`Advertisement`;else{for(let e of[`#video-title`,`#video-title-link`,`yt-formatted-string`]){let n=t.querySelector(e);if(n){let e=(n.textContent||``).trim();if(e){r=e;break}}}if(!r)return;let e=t.querySelector(`ytd-channel-name #text, .ytd-channel-name`);a=e?(e.textContent||``).trim():``}t.setAttribute(`data-intentube-processed`,`true`),_(r,a,e)?(console.log(`Sidebar video allowed:`,r),t.style.removeProperty(`display`)):(console.log(`Sidebar video blocked:`,r),t.style.setProperty(`display`,`none`,`important`),i(1))})}var y=[`Focus is a matter of deciding what things you're not going to do. - John Carmack`,`The successful warrior is the average man, with laser-like focus. - Bruce Lee`,`Concentrate all your thoughts upon the work at hand. The sun's rays do not burn until brought to a focus. - Alexander Graham Bell`,`Lack of direction, not lack of time, is the problem. We all have twenty-four hour days. - Zig Ziglar`,`Starve your distractions, feed your focus. - Unknown`,`Always remember, your focus determines your reality. - George Lucas`,`It is during our darkest moments that we must focus to see the light. - Aristotle Onassis`,`What you focus on grows. - Esther Hicks`,`To do two things at once is to do neither. - Publilius Syrus`,`Focus on the step in front of you, not the whole staircase. - Unknown`,`My success, part of it certainly, is that I have focused in on a few things. - Bill Gates`,`Energy flows where attention goes. - Tony Robbins`,`Do whatever you do intensely. - Robert Henri`,`Focus on being productive instead of busy. - Tim Ferriss`,`You will never reach your destination if you stop and throw stones at every dog that barks. - Winston Churchill`,`Success demands singleness of purpose. - Vince Lombardi`,`The secret of change is to focus all of your energy, not on fighting the old, but on building the new. - Socrates`,`Focus like a laser, not a flashlight. - Michael Jordan`,`Focus 90% of your time on solutions and only 10% of your time on problems. - Anthony J. D'Angelo`,`Focus means eliminating distractions, not just from other people, but the things we do to distract ourselves. - Catherine Pulsifer`,`Your life is controlled by what you focus on. - Tony Robbins`,`One reason so few of us achieve what we truly want is that we never direct our focus. - Tony Robbins`,`Knowing what to leave out is just as important as knowing what to focus on. - Warren Buffett`,`You can do anything, but not everything. - David Allen`,`Realize deeply that the present moment is all you have. Make the NOW the primary focus of your life. - Eckhart Tolle`];function b(){return y[Math.floor(Math.random()*y.length)]}async function x(e,t){return new Promise(n=>{chrome.storage.sync.get({bypassJustifications:[]},r=>{let i=r.bypassJustifications;i.push({videoTitle:e,reason:t,timestamp:Date.now()}),i.length>50&&i.splice(0,i.length-50),chrome.storage.sync.set({bypassJustifications:i},()=>{n()})})})}function S(){if(document.getElementById(`intentube-rich-overlay-styles`))return;let e=document.createElement(`style`);e.id=`intentube-rich-overlay-styles`,e.textContent=`
    .it-rich-overlay {
      position: absolute !important;
      top: 0 !important;
      left: 0 !important;
      width: 100% !important;
      height: 100% !important;
      z-index: 999999 !important;
      display: flex !important;
      flex-direction: column !important;
      justify-content: center !important;
      align-items: center !important;
      background: rgba(15, 23, 42, 0.6) !important;
      backdrop-filter: blur(20px) !important;
      -webkit-backdrop-filter: blur(20px) !important;
      border: 1px solid rgba(255, 255, 255, 0.1) !important;
      border-radius: 12px !important;
      box-sizing: border-box !important;
      font-family: 'Inter', -apple-system, sans-serif !important;
      color: #F8FAFC !important;
      padding: 20px !important;
      opacity: 0;
      animation: stFadeIn 0.3s ease forwards;
    }

    @keyframes stFadeIn {
      from { opacity: 0; transform: scale(0.98); }
      to { opacity: 1; transform: scale(1); }
    }

    .st-ro-header {
      display: flex !important;
      gap: 12px !important;
      margin-bottom: 16px !important;
    }

    .st-ro-badge {
      font-size: 11px !important;
      font-weight: 700 !important;
      padding: 4px 8px !important;
      border-radius: 6px !important;
      text-transform: uppercase !important;
      letter-spacing: 0.5px !important;
    }

    .st-ro-badge.risk-low {
      background: rgba(34, 197, 94, 0.15) !important;
      color: #22C55E !important;
      border: 1px solid rgba(34, 197, 94, 0.3) !important;
    }

    .st-ro-badge.risk-medium {
      background: rgba(234, 179, 8, 0.15) !important;
      color: #EAB308 !important;
      border: 1px solid rgba(234, 179, 8, 0.3) !important;
    }

    .st-ro-badge.risk-high {
      background: rgba(239, 68, 68, 0.15) !important;
      color: #EF4444 !important;
      border: 1px solid rgba(239, 68, 68, 0.3) !important;
    }

    .st-ro-badge.reason {
      background: rgba(255, 255, 255, 0.1) !important;
      color: #CBD5E1 !important;
      border: 1px solid rgba(255, 255, 255, 0.2) !important;
    }

    .st-ro-goal {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      margin-bottom: 20px !important;
      text-align: center !important;
    }

    .st-ro-goal-label {
      font-size: 11px !important;
      color: #94A3B8 !important;
      text-transform: uppercase !important;
      font-weight: 600 !important;
      letter-spacing: 1px !important;
      margin-bottom: 4px !important;
    }

    .st-ro-goal-value {
      font-size: 18px !important;
      font-weight: 700 !important;
      color: #FFFFFF !important;
    }

    .st-ro-alternatives {
      display: flex !important;
      flex-direction: column !important;
      align-items: center !important;
      width: 100% !important;
      margin-bottom: 24px !important;
    }

    .st-ro-alt-label {
      font-size: 12px !important;
      color: #94A3B8 !important;
      margin-bottom: 10px !important;
    }

    .st-ro-chips {
      display: flex !important;
      gap: 8px !important;
      flex-wrap: wrap !important;
      justify-content: center !important;
    }

    .st-ro-chip {
      background: rgba(59, 130, 246, 0.15) !important;
      border: 1px solid rgba(59, 130, 246, 0.4) !important;
      color: #60A5FA !important;
      padding: 6px 12px !important;
      border-radius: 12px !important;
      font-size: 12px !important;
      font-weight: 600 !important;
      cursor: pointer !important;
      text-decoration: none !important;
      transition: all 0.2s ease !important;
    }

    .st-ro-chip:hover {
      background: rgba(59, 130, 246, 0.25) !important;
      transform: translateY(-2px) !important;
    }

    .st-ro-quote {
      font-size: 11px !important;
      color: #64748B !important;
      font-style: italic !important;
      text-align: center !important;
      max-width: 80% !important;
      margin-bottom: 16px !important;
    }

    .st-ro-unlock-btn {
      background: transparent !important;
      color: #64748B !important;
      border: 1px solid rgba(255, 255, 255, 0.1) !important;
      padding: 6px 16px !important;
      border-radius: 20px !important;
      font-size: 11px !important;
      font-weight: 600 !important;
      cursor: pointer !important;
      transition: all 0.2s ease !important;
    }

    .st-ro-unlock-btn:hover {
      color: #F8FAFC !important;
      background: rgba(255, 255, 255, 0.05) !important;
    }

    /* Justification Dialog */
    .st-ro-dialog-title {
      font-size: 14px !important;
      font-weight: 600 !important;
      color: #F8FAFC !important;
      margin-bottom: 16px !important;
    }

    .st-ro-dialog-options {
      display: flex !important;
      flex-direction: column !important;
      gap: 8px !important;
      width: 100% !important;
      max-width: 200px !important;
    }

    .st-ro-dialog-btn {
      background: rgba(17, 24, 39, 0.8) !important;
      border: 1px solid rgba(255, 255, 255, 0.1) !important;
      color: #F8FAFC !important;
      padding: 10px 16px !important;
      border-radius: 8px !important;
      font-size: 13px !important;
      font-weight: 500 !important;
      cursor: pointer !important;
      transition: all 0.2s ease !important;
      text-align: left !important;
    }

    .st-ro-dialog-btn:hover {
      background: rgba(30, 41, 59, 0.9) !important;
      border-color: rgba(255, 255, 255, 0.2) !important;
      transform: translateX(2px) !important;
    }

    .st-ro-dialog-btn.edu:hover { border-color: #3B82F6 !important; }
    .st-ro-dialog-btn.ent:hover { border-color: #EAB308 !important; }
    .st-ro-dialog-btn.brk:hover { border-color: #22C55E !important; }
    
    .st-ro-confirmation {
      font-size: 14px !important;
      font-weight: 600 !important;
      color: #22C55E !important;
      text-align: center !important;
      animation: stFadeIn 0.3s ease forwards;
    }
  `,document.head.appendChild(e)}function C(e,t,n){let r=e;if(r.querySelector(`.it-rich-overlay`))return;r.style.setProperty(`position`,`relative`,`important`),S();let i=document.createElement(`div`);i.className=`it-rich-overlay`,i.addEventListener(`click`,e=>{e.stopPropagation(),e.preventDefault()},!0),i.addEventListener(`mouseenter`,e=>{e.stopPropagation(),e.preventDefault()},!0),T(i,t,n),r.appendChild(i)}function w(e){let t=e.toLowerCase();return[`prank`,`drama`,`gossip`,`tiktok`,`shorts`,`reaction`,`funny`,`fails`].some(e=>t.includes(e))?{label:`🔴 High Risk`,class:`risk-high`}:{label:`🟡 Medium Risk`,class:`risk-medium`}}function T(e,t,n){e.innerHTML=``;let r=document.createElement(`div`);r.className=`st-ro-header`;let i=w(t),a=document.createElement(`div`);a.className=`st-ro-badge ${i.class}`,a.textContent=i.label;let o=document.createElement(`div`);o.className=`st-ro-badge reason`,o.textContent=`Non-Educational Content`,r.appendChild(a),r.appendChild(o);let s=document.createElement(`div`);s.className=`st-ro-goal`;let c=document.createElement(`div`);c.className=`st-ro-goal-label`,c.textContent=`🎯 Current Goal`;let l=document.createElement(`div`);l.className=`st-ro-goal-value`,l.textContent=n.focusGoal||`No goal set`,s.appendChild(c),s.appendChild(l);let u=document.createElement(`div`);u.className=`st-ro-alternatives`;let d=document.createElement(`div`);d.className=`st-ro-alt-label`,d.textContent=`Stay focused on:`;let f=document.createElement(`div`);f.className=`st-ro-chips`,(n.keywords.length>0?n.keywords.slice(0,3):[`Physics`,`Chemistry`,`Mathematics`]).forEach(e=>{let t=document.createElement(`a`);t.className=`st-ro-chip`;let n=`📚`;e.includes(`math`)||e.includes(`calc`)?n=`📐`:e.includes(`phys`)?n=`⚛️`:e.includes(`chem`)?n=`🧪`:(e.includes(`code`)||e.includes(`program`))&&(n=`💻`),t.textContent=`${n} ${e.charAt(0).toUpperCase()+e.slice(1)}`,t.href=`/results?search_query=${encodeURIComponent(e)}`,t.onclick=e=>e.stopPropagation(),f.appendChild(t)}),u.appendChild(d),u.appendChild(f);let p=document.createElement(`div`);p.className=`st-ro-quote`,p.textContent=`"${b()}"`;let m=document.createElement(`button`);m.className=`st-ro-unlock-btn`,m.textContent=`Unlock`,m.onclick=n=>{n.stopPropagation(),E(e,t)},e.appendChild(r),e.appendChild(s),e.appendChild(u),e.appendChild(p),e.appendChild(m)}function E(e,t){e.innerHTML=``;let n=document.createElement(`div`);n.className=`st-ro-dialog-title`,n.textContent=`Why do you want to watch this?`;let r=document.createElement(`div`);r.className=`st-ro-dialog-options`,[{label:`📚 Educational Context`,reason:`Educational`,class:`edu`},{label:`🎉 Entertainment`,reason:`Entertainment`,class:`ent`},{label:`☕ Break Time`,reason:`Break Time`,class:`brk`}].forEach(n=>{let i=document.createElement(`button`);i.className=`st-ro-dialog-btn ${n.class}`,i.textContent=n.label,i.onclick=async r=>{r.stopPropagation(),await x(t,n.reason),D(e)},r.appendChild(i)});let i=document.createElement(`button`);i.className=`st-ro-unlock-btn`,i.style.marginTop=`16px`,i.textContent=`Nevermind, keep focused`,i.onclick=e=>{e.stopPropagation(),window.location.reload()},e.appendChild(n),e.appendChild(r),e.appendChild(i)}function D(e){e.innerHTML=``;let t=document.createElement(`div`);t.className=`st-ro-confirmation`,t.textContent=`Enjoy your break. Stay intentional.`,e.appendChild(t),setTimeout(()=>{e.remove()},1500)}function O(e,t,n){let r=`${e} ${t}`.toLowerCase();return n.some(e=>r.includes(e.toLowerCase()))}async function k(){if(!window.location.pathname.startsWith(`/results`)||!await a())return;let e=await n(),t=e.keywords;document.querySelectorAll(`ytd-video-renderer, ytd-compact-video-renderer, ytd-grid-video-renderer`).forEach(n=>{if(n.hasAttribute(`data-intentube-processed`))return;let r=Array.from(n.querySelectorAll(`.badge-shape-label, .ytd-badge-supported-renderer`)).some(e=>e.textContent?.trim()===`Sponsored`||e.textContent?.trim()===`Ad`),a=``,o=``;if(r||n.tagName.toLowerCase()===`ytd-ad-slot-renderer`)a=`Advertisement`;else{for(let e of[`#video-title`,`#video-title-link`,`yt-formatted-string.ytd-video-renderer`]){let t=n.querySelector(e);if(t){let e=(t.textContent||``).trim();if(e){a=e;break}}}if(!a)return;let e=n.querySelector(`ytd-channel-name #text, .ytd-channel-name`);o=e?(e.textContent||``).trim():``}n.setAttribute(`data-intentube-processed`,`true`),O(a,o,t)?console.log(`Search video allowed:`,a):(console.log(`Search video locked:`,a),C(n,a,e),i(1))})}var A=!1,j=null;function M(){if(A){j||=window.setTimeout(()=>{j=null,M()},500);return}A=!0,d(),g(),v(),k(),A=!1}function N(){console.log(`IntenTube initialized`),M(),document.addEventListener(`yt-navigate-finish`,()=>{M()}),new MutationObserver(e=>{e.some(e=>e.addedNodes.length>0)&&M()}).observe(document.body,{childList:!0,subtree:!0})}N();